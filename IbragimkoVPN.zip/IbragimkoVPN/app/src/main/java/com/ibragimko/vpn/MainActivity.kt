package com.ibragimko.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {
    private val requestCode = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(R.style.Theme_IbragimkoVPN)
        setContentView(R.layout.activity_main)

        val btn = findViewById<MaterialButton>(R.id.btnConnect)
        btn.setOnClickListener {
            val intent = VpnService.prepare(this)
            if (intent != null) startActivityForResult(intent, requestCode)
            else startVpn()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode && resultCode == Activity.RESULT_OK) {
            startVpn()
        }
    }

    private fun startVpn() {
        startService(Intent(this, WgVpnService::class.java).apply {
            // For demo: reads client1.conf from assets
            putExtra("CONFIG_TEXT", assets.open("client1.conf").bufferedReader().readText())
        })
    }
}
