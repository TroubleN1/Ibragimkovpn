package com.ibragimko.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import java.io.File

class WgVpnService : VpnService() {
    private var proc: Process? = null
    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, notif(getString(R.string.status_connecting)))

        // Create TUN
        val builder = Builder().setSession("IbragimkoVPN").setMtu(1280)
        builder.addAddress("10.7.0.2", 32)
        builder.addDnsServer("1.1.1.1"); builder.addDnsServer("8.8.8.8")
        builder.addRoute("0.0.0.0", 0); builder.addRoute("::", 0)
        tun = builder.establish()

        // Extract binary (placeholder). You MUST provide binaries under assets/wireguard/ABI/wireguard-go
        val bin = try { extractBinaryForAbi("wireguard-go") } catch (e: Exception) {
            updateNotif("Нужен wireguard-go в assets/wireguard/ABI/"); stopSelf(); return START_NOT_STICKY
        }

        // Config
        val cfg = intent?.getStringExtra("CONFIG_TEXT") ?: ""
        val cfgFile = File(filesDir, "wg.conf").apply { writeText(cfg) }

        // Launch userspace engine
        val cmd = arrayOf(bin.absolutePath, "-f", "-tunfd", tun!!.fd.toString(), cfgFile.absolutePath)
        proc = try { ProcessBuilder(*cmd).redirectErrorStream(true).start() } catch (e: Exception) {
            updateNotif("Не удалось запустить движок"); stopSelf(); return START_NOT_STICKY
        }

        updateNotif(getString(R.string.status_connected))
        return START_STICKY
    }

    override fun onDestroy() {
        try { proc?.destroy() } catch (_: Exception) {}
        try { tun?.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun notif(text: String): Notification {
        val id = "vpn"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(id, "VPN", NotificationManager.IMPORTANCE_LOW))
        }
        return NotificationCompat.Builder(this, id)
            .setSmallIcon(R.drawable.ic_vpn)
            .setContentTitle("IbragimkoVPN")
            .setContentText(text).build()
    }

    private fun updateNotif(text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1, notif(text))
    }

    private fun extractBinaryForAbi(name: String): File {
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: throw IllegalStateException("ABI not found")
        val inPath = "wireguard/$abi/$name"
        val out = File(filesDir, "$name-$abi")
        assets.open(inPath).use { input -> out.outputStream().use { input.copyTo(it) } }
        out.setExecutable(true); return out
    }
}
